﻿

namespace esqueletoProgramaCRUDconBD.B_DTOs.DepTecnico
{
    public class TecnicoDTO: TrabDepTecnicoDTO
    {
        public JefeEquipoDTO Jefe { get; set; }
    }
}
