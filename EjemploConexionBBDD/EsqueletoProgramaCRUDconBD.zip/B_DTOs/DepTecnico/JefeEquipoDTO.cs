﻿

namespace esqueletoProgramaCRUDconBD.B_DTOs.DepTecnico
{
    public class JefeEquipoDTO: TrabDepTecnicoDTO
    {
    }
}
